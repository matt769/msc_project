----------------------------------------
For firmware update on Windows or Linux:
----------------------------------------

1.  Install FlyCapture2 for either windows or linux.  Installers can be downloaded from our downloads site at http://www.ptgrey.com/support/downloads/.

2.  Plug your camera(s) in.  Cameras must show up in FlyCapture2.  If they do not show up, install FlyCapture2.X and the associated drivers (if applicable) and ensure cameras are visible in FlyCap2 demo.

3.  Run UpdatorGUI2.exe or UpdatorGUI3.exe (depending on version of FlyCapture2.X) installed in your bin/bin64 folder:

On 32 bit Windows: C:\Program Files\Point Grey Research\FlyCapture2\bin
On 64 bit Windows: C:\Program Files\Point Grey Research\FlyCapture2\bin64

4.  Select the camera(s) to update, point to the .ez2 file downloaded with this package, and select "Update".

Camera(s) should now be updated.  Please note a power cycle of the cameras should not be required, as they are automatically rebooted after firmware update.

For any questions or to report any issues, please contact Point Grey support at support@ptgrey.com

